Template Gotra extraido

La carpeta gotra/ contiene:
- demo-files/gotra.WordPress.2025-11-25.xml
- demo-files/lalita-export.dat
- demo-files/wpkoi.com-demos3-gotra-premium-widgets.wie
- gotra-defaults.php

Nota: esto no es un tema WordPress instalable por si solo; es la parte de demo/template separada del paquete.
