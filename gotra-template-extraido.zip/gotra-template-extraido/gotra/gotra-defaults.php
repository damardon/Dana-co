<?php
// No direct access, please
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Default values for premium features

if ( ! function_exists( 'lalita_menu_plus_color_defaults' ) ) {
	add_filter( 'lalita_color_option_defaults', 'lalita_menu_plus_color_defaults' );
	/**
	 * Set MENU PLUS color defaults
	 *
	 */
	function lalita_menu_plus_color_defaults( $defaults ) {
		$defaults[ 'slideout_background_color' ] = '#eeeeee';
		$defaults[ 'slideout_text_color' ] = '#222222';
		$defaults[ 'slideout_background_hover_color' ] = 'rgba(255,255,255,0)';
		$defaults[ 'slideout_text_hover_color' ] = '#000000';
		$defaults[ 'slideout_background_current_color' ] = 'rgba(255,255,255,0)';
		$defaults[ 'slideout_text_current_color' ] = '';
		$defaults[ 'slideout_submenu_background_color' ] = 'rgba(255,255,255,0)';
		$defaults[ 'slideout_submenu_text_color' ] = '';
		$defaults[ 'slideout_submenu_background_hover_color' ] = '';
		$defaults[ 'slideout_submenu_text_hover_color' ] = '';
		$defaults[ 'slideout_submenu_background_current_color' ] = '';
		$defaults[ 'slideout_submenu_text_current_color' ] = '';
	
		return $defaults;
	}
}

if ( ! function_exists( 'lalita_wc_color_defaults' ) ) {
	add_filter( 'lalita_color_option_defaults', 'lalita_wc_color_defaults' );
	/**
	 * Set the WC color option defaults.
	 *
	 */
	function lalita_wc_color_defaults( $defaults ) {
		$defaults[ 'wc_alt_button_background' ] = '#eeeeee';
		$defaults[ 'wc_alt_button_background_hover' ] = '#ffffff';
		$defaults[ 'wc_alt_button_text' ] = '#222222';
		$defaults[ 'wc_alt_button_text_hover' ] = '#222222';
		$defaults[ 'wc_rating_stars' ] = '#eeeeee';
		$defaults[ 'wc_sale_sticker_background' ] = '#eeeeee';
		$defaults[ 'wc_sale_sticker_text' ] = '#222222';
		$defaults[ 'wc_price_color' ] = '#eeeeee';
		$defaults[ 'wc_product_tab' ] = '#ffffff';
		$defaults[ 'wc_product_tab_highlight' ] = '#eeeeee';
		$defaults[ 'wc_success_message_background' ] = '#0b9444';
		$defaults[ 'wc_success_message_text' ] = '#ffffff';
		$defaults[ 'wc_info_message_background' ] = '#1e73be';
		$defaults[ 'wc_info_message_text' ] = '#ffffff';
		$defaults[ 'wc_error_message_background' ] = '#e8626d';
		$defaults[ 'wc_error_message_text' ] = '#ffffff';
		$defaults[ 'wc_product_title_color' ] = '';
		$defaults[ 'wc_product_title_color_hover' ] = '';
	
		return $defaults;
	}
}
	
if ( ! function_exists( 'lalita_get_default_color_palettes' ) ) {
	/**
	 * Set up our colors for the color picker palettes and filter them so you can change them.
	 *
	 */
	function lalita_get_default_color_palettes() {
		$palettes = array(
			'rgba(0,0,0,0)',
			'#000000',
			'#222222',
			'#888888',
			'#eeeeee',
			'#ffffff'
		);
	
		return apply_filters( 'lalita_default_color_palettes', $palettes );
	}
}

if ( ! function_exists( 'lalita_typography_default_fonts' ) ) {
	/**
	 * Set the default system fonts.
	 *
	 */
	function lalita_typography_default_fonts() {
		$fonts = array(
			'inherit',
			'System Stack',
			'Arial, Helvetica, sans-serif',
			'Courier New',
			'Georgia, Times New Roman, Times, serif',
			'Trebuchet MS, Helvetica, sans-serif',
			'Verdana, Geneva, sans-serif',
			'Poppins'
		);
	
		return apply_filters( 'lalita_typography_default_fonts', $fonts );
	}
}

if ( ! function_exists( 'lalita_premium_default_fonts' ) ) {
	function lalita_premium_default_fonts() {
		return '//fonts.googleapis.com/css?family=Poppins:300,regular,500,600,700';
	}
}