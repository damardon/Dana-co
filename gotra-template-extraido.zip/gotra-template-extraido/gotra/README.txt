Template: gotra

Contenido extraido desde el paquete lalita-premium:
- demo-files/: archivos de importacion del demo/template (XML, DAT, WIE si existen)
- gotra-defaults.php: defaults del template si existia en inc/defaults

Nota: esto no es un tema WordPress instalable por si solo; es la parte de demo/template separada del paquete.
